import com.jogamp.newt.event.MouseAdapter;
import com.jogamp.newt.event.MouseEvent;

public class MouseInput extends MouseAdapter {
    private EventListener eventListener;

    public MouseInput(EventListener eventListener) {
        this.eventListener = eventListener;
    }

    @Override
    public void mouseClicked(MouseEvent e) {
        System.out.println("Mouse clicked");
        eventListener.triggerJump();
    }
}
