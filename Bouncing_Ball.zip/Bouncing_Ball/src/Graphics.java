import com.jogamp.opengl.GL2;

public class Graphics {
    public static void fillRec(GL2 gl, float x, float y, float width, float height, float r, float g, float b) {
        gl.glColor3f(r, g, b); // Use the passed colors
        gl.glBegin(GL2.GL_QUADS);
        gl.glVertex2f(x, y);
        gl.glVertex2f(x + width, y);
        gl.glVertex2f(x + width, y + height);
        gl.glVertex2f(x, y + height);
        gl.glEnd();
    }

    public static void renderCircle(GL2 gl, float cx, float cy, float r, int num_segments) {
        gl.glColor3f(0, 0, 1); // Blue color for the circle
        gl.glBegin(GL2.GL_TRIANGLE_FAN);
        gl.glVertex2f(cx, cy); // Center of circle
        for (int i = 0; i <= num_segments; i++) {
            double theta = 2.0 * Math.PI * i / num_segments;
            float x = (float) (r * Math.cos(theta));
            float y = (float) (r * Math.sin(theta));
            gl.glVertex2f(x + cx, y + cy);
        }
        gl.glEnd();
    }
}
