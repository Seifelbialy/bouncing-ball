import com.jogamp.opengl.*;

import javax.swing.*;

public class EventListener implements GLEventListener {
    private float circleY = 300;
    private float jumpVelocity = 0;
    private boolean isJumping = false;
    private boolean isStarted = false;
    private final float radius = 20.0f;
    private final float[] obstacleX = new float[3];  // Positions for three obstacles
    private final float obstacleWidth = 50;
    private final float obstacleHeight = 20;
    private final float[] colors = new float[9];  // RGB for three obstacles
    private int score = 0;

    public EventListener() {
        initializeObstacles();
    }

    private void initializeObstacles() {
        for (int i = 0; i < obstacleX.length; i++) {
            obstacleX[i] = 800 + 300 * i;  // Stagger obstacles
            int colorIndex = i * 3;
            colors[colorIndex] = (float) Math.random();      // Red component
            colors[colorIndex + 1] = (float) Math.random();  // Green component
            colors[colorIndex + 2] = (float) Math.random();  // Blue component
        }
    }

    @Override
    public void init(GLAutoDrawable drawable) {
        GL2 gl = drawable.getGL().getGL2();
        gl.glClearColor(0.8f, 0.8f, 1.0f, 1.0f);
    }

    @Override
    public void dispose(GLAutoDrawable drawable) {}

    @Override
    public void display(GLAutoDrawable drawable) {
        GL2 gl = drawable.getGL().getGL2();
        gl.glClear(GL.GL_COLOR_BUFFER_BIT | GL.GL_DEPTH_BUFFER_BIT);

        if (isStarted) {
            handleJumping();
            moveAndRenderObstacles(gl);
        }

        Graphics.renderCircle(gl, 400, circleY, radius, 100);

        gl.glFlush();
    }

    private void handleJumping() {
        if (isJumping) {
            circleY += jumpVelocity;
            jumpVelocity -= 1;  // Gravity effect
            if (circleY < 300) {
                circleY = 300;
                isJumping = false;
                jumpVelocity = 0;
            }
        }
    }

    private void moveAndRenderObstacles(GL2 gl) {
        for (int i = 0; i < obstacleX.length; i++) {
            obstacleX[i] -= 5;
            if (obstacleX[i] + obstacleWidth < 0) {
                obstacleX[i] = 800;  // Reset the obstacle
                score++;  // Increase the score
                // Randomize colors
                int colorIndex = i * 3;
                colors[colorIndex] = (float) Math.random();
                colors[colorIndex + 1] = (float) Math.random();
                colors[colorIndex + 2] = (float) Math.random();
            }
            int colorIndex = i * 3;
            Graphics.fillRec(gl, obstacleX[i], 280, obstacleWidth, obstacleHeight, colors[colorIndex], colors[colorIndex + 1], colors[colorIndex + 2]);

            // Check for collision
            if (circleY <= 300 && (obstacleX[i] <= 400 + radius && obstacleX[i] + obstacleWidth >= 400 - radius)) {
                System.out.println("Collision Detected! Score: " + score);
                showGameOverDialog();
                return;  // Stop further processing
            }
        }
        System.out.println("Score: " + score);
    }

    private void showGameOverDialog() {
        isStarted = false;
        JOptionPane.showMessageDialog(null, "Game Over! Your score: " + score, "Game Over", JOptionPane.INFORMATION_MESSAGE);
        resetGame();
    }

    private void resetGame() {
        circleY = 300;
        jumpVelocity = 0;
        isJumping = false;
        score = 0;
        initializeObstacles();
        System.out.println("Game reset!");
    }

    @Override
    public void reshape(GLAutoDrawable drawable, int x, int y, int width, int height) {
        GL2 gl = drawable.getGL().getGL2();
        gl.glViewport(0, 0, width, height);
        gl.glMatrixMode(GL2.GL_PROJECTION);
        gl.glLoadIdentity();
        gl.glOrtho(0, width, 0, height, -1, 1);
        gl.glMatrixMode(GL2.GL_MODELVIEW);
        gl.glLoadIdentity();
    }

    public void triggerJump() {
        if (!isStarted) {
            isStarted = true;
        }
        if (!isJumping && circleY == 300) {
            isJumping = true;
            jumpVelocity = 20;  // Adjust velocity to make the jump more visible
            System.out.println("Jump triggered");
        }
    }

    public float getRadius() {
        return radius;
    }

    public float getCircleY() {
        return circleY;
    }
}
